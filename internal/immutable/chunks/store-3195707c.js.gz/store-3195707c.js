import{w as o}from"./index-51af0e43.js";const t=o(!0);export{t as l};
