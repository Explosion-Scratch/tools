import{S as f,i,s as g,e as d,t as h,N as c,c as m,a as s,h as x,d as l,b as y,F as n,E as e}from"./index-b92f0203.js";function u(b){let t,o;return{c(){t=d("style"),o=h(`:global(.tippy-box[data-theme~='light']) {
			color: #26323d;
			font-family: monospace;
			box-shadow: 0 0 20px 4px rgba(154, 161, 177, 0.15), 0 4px 80px -8px rgba(36, 40, 47, 0.25),
				0 4px 4px -2px rgba(91, 94, 105, 0.15);
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='top']) > :global(.tippy-arrow:before) {
			border-top-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='bottom']) > :global(.tippy-arrow:before) {
			border-bottom-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='left']) > :global(.tippy-arrow:before) {
			border-left-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='right']) > :global(.tippy-arrow:before) {
			border-right-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-backdrop) {
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-svg-arrow) {
			fill: #fff;
		}`),this.h()},l(r){const a=c('[data-svelte="svelte-1k039ou"]',document.head);t=m(a,"STYLE",{global:!0});var p=s(t);o=x(p,`:global(.tippy-box[data-theme~='light']) {
			color: #26323d;
			font-family: monospace;
			box-shadow: 0 0 20px 4px rgba(154, 161, 177, 0.15), 0 4px 80px -8px rgba(36, 40, 47, 0.25),
				0 4px 4px -2px rgba(91, 94, 105, 0.15);
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='top']) > :global(.tippy-arrow:before) {
			border-top-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='bottom']) > :global(.tippy-arrow:before) {
			border-bottom-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='left']) > :global(.tippy-arrow:before) {
			border-left-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='right']) > :global(.tippy-arrow:before) {
			border-right-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-backdrop) {
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-svg-arrow) {
			fill: #fff;
		}`),p.forEach(l),a.forEach(l),this.h()},h(){y(t,"global","")},m(r,a){n(document.head,t),n(t,o)},p:e,i:e,o:e,d(r){l(t)}}}class _ extends f{constructor(t){super(),i(this,t,null,u,g,{})}}export{_ as T};
