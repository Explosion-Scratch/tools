import{w as o}from"./index-8bd30b3e.js";const t=o(!0);export{t as l};
