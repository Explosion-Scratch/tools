import{w as o}from"./index-3da1257c.js";const t=o(!0);export{t as l};
