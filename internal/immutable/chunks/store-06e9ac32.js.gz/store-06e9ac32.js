import{w as o}from"./index-c9376b27.js";const t=o(!0);export{t as l};
