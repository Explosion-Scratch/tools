import{w as o}from"./index-72a63e98.js";const t=o(!0);export{t as l};
