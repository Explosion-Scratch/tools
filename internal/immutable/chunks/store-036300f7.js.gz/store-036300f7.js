import{w as o}from"./index-6fc5bc1a.js";const t=o(!0);export{t as l};
