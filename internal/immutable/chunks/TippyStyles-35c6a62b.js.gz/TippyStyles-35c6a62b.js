import{S as _,i as w,s as v,e as n,t as k,N as E,c as b,a as c,d as e,h as S,Z as m,b as i,F as r,E as f}from"./index-b92f0203.js";function T(x){let t,s,o,g,a,p;return{c(){t=n("script"),o=n("script"),a=n("style"),p=k(`:global(.tippy-box[data-theme~='light']) {
			color: #26323d;
			font-family: monospace;
			box-shadow: 0 0 20px 4px rgba(154, 161, 177, 0.15), 0 4px 80px -8px rgba(36, 40, 47, 0.25),
				0 4px 4px -2px rgba(91, 94, 105, 0.15);
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='top']) > :global(.tippy-arrow:before) {
			border-top-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='bottom']) > :global(.tippy-arrow:before) {
			border-bottom-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='left']) > :global(.tippy-arrow:before) {
			border-left-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='right']) > :global(.tippy-arrow:before) {
			border-right-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-backdrop) {
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-svg-arrow) {
			fill: #fff;
		}`),this.h()},l(d){const l=E('[data-svelte="svelte-19lgixc"]',document.head);t=b(l,"SCRIPT",{src:!0});var y=c(t);y.forEach(e),o=b(l,"SCRIPT",{src:!0});var u=c(o);u.forEach(e),a=b(l,"STYLE",{global:!0});var h=c(a);p=S(h,`:global(.tippy-box[data-theme~='light']) {
			color: #26323d;
			font-family: monospace;
			box-shadow: 0 0 20px 4px rgba(154, 161, 177, 0.15), 0 4px 80px -8px rgba(36, 40, 47, 0.25),
				0 4px 4px -2px rgba(91, 94, 105, 0.15);
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='top']) > :global(.tippy-arrow:before) {
			border-top-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='bottom']) > :global(.tippy-arrow:before) {
			border-bottom-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='left']) > :global(.tippy-arrow:before) {
			border-left-color: #fff;
		}
		:global(.tippy-box[data-theme~='light'][data-placement^='right']) > :global(.tippy-arrow:before) {
			border-right-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-backdrop) {
			background-color: #fff;
		}
		:global(.tippy-box[data-theme~='light']) > :global(.tippy-svg-arrow) {
			fill: #fff;
		}`),h.forEach(e),l.forEach(e),this.h()},h(){m(t.src,s="https://unpkg.com/@popperjs/core@2")||i(t,"src",s),m(o.src,g="https://unpkg.com/tippy.js@6")||i(o,"src",g),i(a,"global","")},m(d,l){r(document.head,t),r(document.head,o),r(document.head,a),r(a,p)},p:f,i:f,o:f,d(d){e(t),e(o),e(a)}}}class C extends _{constructor(t){super(),w(this,t,null,T,v,{})}}export{C as T};
