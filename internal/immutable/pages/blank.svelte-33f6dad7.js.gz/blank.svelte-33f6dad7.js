import{S as t,i as e,s as a}from"../chunks/index-195d8f08.js";class o extends t{constructor(s){super(),e(this,s,null,null,a,{})}}export{o as default};
