import{S as t,i as e,s as a}from"../chunks/index-b92f0203.js";class o extends t{constructor(s){super(),e(this,s,null,null,a,{})}}export{o as default};
