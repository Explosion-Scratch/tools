import{S as t,i as e,s as a}from"../chunks/index-6d454735.js";class o extends t{constructor(s){super(),e(this,s,null,null,a,{})}}export{o as default};
